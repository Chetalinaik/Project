import React from 'react'
// import GreetingFromClass from './components/GreetingFromClass'
import {BrowserRouter,Route, Routes} from 'react-router-dom'
import GreetingFromClass from './components/GreetingFromClass'
export default function App() {
  return (
    <div className='App'>
      <BrowserRouter>
      <Routes>
        <Route path="/c" element={<GreetingFromClass/>}/>
      </Routes>
      </BrowserRouter>
    </div>
  )
}
