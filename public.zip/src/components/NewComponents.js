import React from 'react'

function NewComponents(props) {
  return (
    <div>
        <h1>Good Morning{props.name}</h1>

    </div>
  )
}

export default NewComponents