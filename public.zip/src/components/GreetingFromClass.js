import React, { Component } from 'react'

export default class GreetingFromClass extends Component {
  render() {
    return (
      <div>
        <h1>Name:{this.props.name}</h1>
        <h1>Age:{this.props.age}</h1>
        <h1>Class:{this.props.class}</h1>
        <h1>Department:{this.props.department}</h1>
        <h1>College:{this.props.college}</h1>

      </div>
    )
  }
}
